package esprit.tn.savvy.repositories;

import esprit.tn.savvy.entities.DeliveryPerson;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepDeliveryPerson extends JpaRepository<DeliveryPerson,Integer> {

}
