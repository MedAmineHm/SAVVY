package esprit.tn.savvy.entities;

public enum Status {
    PENDING, IN_PROGRESS, DELIVERED, CANCELED
}
