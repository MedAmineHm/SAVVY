package esprit.tn.savvy.controller;

import esprit.tn.savvy.entities.Delivery;
import esprit.tn.savvy.entities.Status;
import esprit.tn.savvy.services.IDeliveryService;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("delivery")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ControllerDelivery {
    IDeliveryService deliveryService;

    @PostMapping("add")
    public Delivery adddelivery(@RequestBody Delivery delivery) {
        return deliveryService.adddelivery(delivery);
    }

    @GetMapping("findall")
    public List<Delivery> retrieveAllDelivery() {
        return deliveryService.getAllDelivery();
    }

    @GetMapping("{idDelivery}")
    public Delivery retrievebyid(@PathVariable Integer idDelivery) {
        return deliveryService.retrievedelivery(idDelivery);

    }

    @DeleteMapping("{idDelivery}")
    public void removedeliverybyid(@PathVariable Integer idDelivery) {
        Delivery delivery = deliveryService.retrievedelivery(idDelivery);
        if (delivery != null) {
            deliveryService.removedelivery(delivery);
        }

    }
    @PutMapping("{idDelivery}")
    public Delivery updateDelivery(@PathVariable Integer idDelivery, @RequestBody Delivery delivery) {
        delivery.setIdDelivery(idDelivery);
        return deliveryService.update(delivery);
    }

    @GetMapping("getByStatus/{status}")
    public List<Delivery> retrieveDeliveriesByStatus(@PathVariable("status") Status status)
    {
        return deliveryService.retrieveDeliveriesByStatus(status);
    }
    @GetMapping("/byDeliveryDate")
    public List<Delivery> findByDeliveryDate(@RequestParam("deliveryDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date deliveryDate)
    {
        return deliveryService.findByDeliveryDate(deliveryDate);
    }
}
