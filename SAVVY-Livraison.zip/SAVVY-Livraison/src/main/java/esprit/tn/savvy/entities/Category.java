package esprit.tn.savvy.entities;

public enum Category {
TEXTILE, NOURRITURE, MEUBLE, ELECTROMENAGER
}
